INSERT INTO courses (name, rating) VALUES
('Docker and Kubernetes', 4.5),
('AI-102 Azure AI Engineer', 4.6),
('AZ-104 Azure Administrator', 4.7);