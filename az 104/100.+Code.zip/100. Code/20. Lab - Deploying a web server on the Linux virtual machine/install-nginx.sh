#!/bin/bash
# Update package lists
sudo apt update -y

# Install Nginx
sudo apt install -y nginx