<?php
  echo "<html>";
  echo "<head><title>Azure PHP Web App</title></head>";
  echo "<body style='font-family: Arial, sans-serif; text-align: center; margin-top: 50px;'>";
  echo "<h1>Hello from Azure Web Apps (PHP)</h1>";
  echo "<p>This is a simple PHP application running on Azure App Service.</p>";
  echo "</body>";
  echo "</html>";
?>
